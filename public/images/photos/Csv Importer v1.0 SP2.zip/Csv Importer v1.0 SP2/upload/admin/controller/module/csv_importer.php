<?php 
class ControllerModuleCsvImporter extends Controller {
	private $error = array();
	private $value = array();
	private $setting = array();

	public function install() {


	}



	public function uninstall() {

	}
	
	public function index() {
		$this->load->language('module/csv_importer');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('module/csv_importer');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {
			if ((isset( $this->request->files['upload'] )) && (is_uploaded_file($this->request->files['upload']['tmp_name']))) {
				$file = $this->request->files['upload']['tmp_name'];
				if ($this->model_module_csv_importer->upload($file)==TRUE) {
					$this->session->data['success'] = $this->language->get('text_success');
					$this->response->redirect($this->url->link('module/csv_importer', 'token=' . $this->session->data['token'], 'SSL'));
				}	
				else {
					$this->error['warning'] = $this->language->get('error_upload');
				}
			}
		}
		$this->OutWiev();
	}

    protected function OutWiev(){	

		if (!empty($this->session->data['export_error']['errstr'])) {
			$this->error['warning'] = $this->session->data['export_error']['errstr'];
			if (!empty($this->session->data['export_nochange'])) {
				$this->error['warning'] .= '<br />'.$this->language->get( 'text_nochange' );
			}
			$this->error['warning'] .= '<br />'.$this->language->get( 'text_log_details' );
		}
		unset($this->session->data['export_error']);
		unset($this->session->data['export_nochange']);

		$data['heading_title'] = $this->language->get('heading_title');
		$data['setting_import'] = $this->language->get('setting_import');
		$data['import_title'] = $this->language->get('import_title');
		$data['entry_restore'] = $this->language->get('entry_restore');
		$data['entry_description'] = $this->language->get('entry_description');
		$data['image_field'] = $this->language->get('image_field');
		$data['name_field'] = $this->language->get('name_field');
		$data['model_field'] = $this->language->get('model_field'); 
		$data['price_field'] = $this->language->get('price_field');
		$data['guantity_field'] = $this->language->get('guantity_field');
		$data['statusenabled_field'] = $this->language->get('statusenabled_field');
		$data['sku_field'] = $this->language->get('sku_field');
		$data['manufacturer_field'] = $this->language->get('manufacturer_field');
		$data['description_field'] = $this->language->get('description_field');
		$data['categories_field'] = $this->language->get('categories_field');
		$data['row_size'] = $this->language->get('row_size');
		$data['min_size_comment'] = $this->language->get('min_size_comment');
		$data['max_size_comment'] = $this->language->get('max_size_comment');
		$data['separator_export'] = $this->language->get('separator_export');
		$data['separator_import'] = $this->language->get('separator_import');
		$data['button_import'] = $this->language->get('button_import');
		$data['button_export'] = $this->language->get('button_export');
		$data['button_enter'] = $this->language->get('button_enter');
		$data['tab_general'] = $this->language->get('tab_general');
		$data['error_select_file'] = $this->language->get('error_select_file');
		$data['error_post_max_size'] = str_replace( '%1', ini_get('post_max_size'), $this->language->get('error_post_max_size') );
		$data['error_upload_max_filesize'] = str_replace( '%1', ini_get('upload_max_filesize'), $this->language->get('error_upload_max_filesize') );
        $data['url'] = $this->session->data['token'];
		$data['setting_export'] = $this->language->get('setting_export');
		$data['export_title'] = $this->language->get('export_title');
		$data['row_size_export'] = $this->language->get('row_size_export');
		$data['number_column'] = $this->language->get('number_column');
		
		if (empty($this->session->data['settings_on'])){
		
		    $this->session->data['settings_on']=0;
		}
		
		
 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => FALSE
		);

		$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('module/csv_importer', 'token=' . $this->session->data['token'], 'SSL'),
			'separator' => ' :: '
		);
		
		$data['action'] = $this->url->link('module/csv_importer', 'token=' . $this->session->data['token'], 'SSL');
		$data['export'] = $this->url->link('module/csv_importer/download', 'token=' . $this->session->data['token'], 'SSL');
		$data['post_max_size'] = $this->return_bytes( ini_get('post_max_size') );
	    $data['text_modified_ok'] = $this->language->get('text_modified_ok');
		$data['text_modified_error'] = $this->language->get('text_modified_error');
		$data['text_error_end_row'] = $this->language->get('text_error_end_row');
		$data['text_error_max_row'] = $this->language->get('text_error_max_row');
	    $data['text_row_number_zero'] = $this->language->get('text_row_number_zero');
		$data['text_export_started'] = $this->language->get('text_export_started');
		$data['text_help_export'] = $this->language->get('text_help_export');
		$data['upload_max_filesize'] = $this->return_bytes( ini_get('upload_max_filesize') );
		$data['text_settings_ok'] = $this->language->get('text_settings_ok');
		
		$this->Output($data);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('module/csv_importer.tpl', $data));
	}
	
	protected function detect_encoding( $str ) {
		// auto detect the character encoding of a string
		return mb_detect_encoding( $str, 'UTF-8,ISO-8859-15,ISO-8859-1,cp1251,KOI8-R' );
	}
	
	 protected function Output(&$data){

		 if (isset($this->request->post['csv_importer_setting_import_image'])) {
			 $data['csv_importer_setting_import_image'] = $this->request->post['csv_importer_setting_import_image'];
		 } elseif ($this->config->get('csv_importer_setting_import_image')) {
			 $data['csv_importer_setting_import_image'] = $this->config->get('csv_importer_setting_import_image');
		 } else {
			 $data['csv_importer_setting_import_image'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_name'])) {
			 $data['csv_importer_setting_import_name'] = $this->request->post['csv_importer_setting_import_name'];
		 } elseif ($this->config->get('csv_importer_setting_import_name')) {
			 $data['csv_importer_setting_import_name'] = $this->config->get('csv_importer_setting_import_name');
		 } else {
			 $data['csv_importer_setting_import_name'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_model'])) {
			 $data['csv_importer_setting_import_model'] = $this->request->post['csv_importer_setting_import_model'];
		 } elseif ($this->config->get('csv_importer_setting_import_model')) {
			 $data['csv_importer_setting_import_model'] = $this->config->get('csv_importer_setting_import_model');
		 } else {
			 $data['csv_importer_setting_import_model'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_price'])) {
			 $data['csv_importer_setting_import_price'] = $this->request->post['csv_importer_setting_import_price'];
		 } elseif ($this->config->get('csv_importer_setting_import_price')) {
			 $data['csv_importer_setting_import_price'] = $this->config->get('csv_importer_setting_import_price');
		 } else {
			 $data['csv_importer_setting_import_price'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_quantity'])) {
			 $data['csv_importer_setting_import_quantity'] = $this->request->post['csv_importer_setting_import_quantity'];
		 } elseif ($this->config->get('csv_importer_setting_import_quantity')) {
			 $data['csv_importer_setting_import_quantity'] = $this->config->get('csv_importer_setting_import_quantity');
		 } else {
			 $data['csv_importer_setting_import_quantity'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_statusenabled'])) {
			 $data['csv_importer_setting_import_statusenabled'] = $this->request->post['csv_importer_setting_import_statusenabled'];
		 } elseif ($this->config->get('csv_importer_setting_import_statusenabled')) {
			 $data['csv_importer_setting_import_statusenabled'] = $this->config->get('csv_importer_setting_import_statusenabled');
		 } else {
			 $data['csv_importer_setting_import_statusenabled'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_sku'])) {
			 $data['csv_importer_setting_import_sku'] = $this->request->post['csv_importer_setting_import_sku'];
		 } elseif ($this->config->get('csv_importer_setting_import_sku')) {
			 $data['csv_importer_setting_import_sku'] = $this->config->get('csv_importer_setting_import_sku');
		 } else {
			 $data['csv_importer_setting_import_sku'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_manufacturer'])) {
			 $data['csv_importer_setting_import_manufacturer'] = $this->request->post['csv_importer_setting_import_manufacturer'];
		 } elseif ($this->config->get('csv_importer_setting_import_manufacturer')) {
			 $data['csv_importer_setting_import_manufacturer'] = $this->config->get('csv_importer_setting_import_manufacturer');
		 } else {
			 $data['csv_importer_setting_import_manufacturer'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_description'])) {
			 $data['csv_importer_setting_import_description'] = $this->request->post['csv_importer_setting_import_description'];
		 } elseif ($this->config->get('csv_importer_setting_import_description')) {
			 $data['csv_importer_setting_import_description'] = $this->config->get('csv_importer_setting_import_description');
		 } else {
			 $data['csv_importer_setting_import_description'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_categories'])) {
			 $data['csv_importer_setting_import_categories'] = $this->request->post['csv_importer_setting_import_categories'];
		 } elseif ($this->config->get('csv_importer_setting_import_categories')) {
			 $data['csv_importer_setting_import_categories'] = $this->config->get('csv_importer_setting_import_categories');
		 } else {
			 $data['csv_importer_setting_import_categories'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_import_separator'])) {
			 $data['csv_importer_setting_import_separator'] = $this->request->post['csv_importer_setting_import_separator'];
		 } elseif ($this->config->get('csv_importer_setting_import_separator')) {
			 $data['csv_importer_setting_import_separator'] = $this->config->get('csv_importer_setting_import_separator');
		 } else {
			 $data['csv_importer_setting_import_separator'] = 0;
		 }
		 
		 if (isset($this->request->post['csv_importer_setting_import_image_checked'])) {
			 $data['csv_importer_setting_import_image_checked'] = $this->request->post['csv_importer_setting_import_image_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_image_checked')) {
			 $data['csv_importer_setting_import_image_checked'] = $this->config->get('csv_importer_setting_import_image_checked');
		 } else {
			 $data['csv_importer_setting_import_image_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_name_checked'])) {
			 $data['csv_importer_setting_import_name_checked'] = $this->request->post['csv_importer_setting_import_name_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_name_checked')) {
			 $data['csv_importer_setting_import_name_checked'] = $this->config->get('csv_importer_setting_import_name_checked');
		 } else {
			 $data['csv_importer_setting_import_name_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_model_checked'])) {
			 $data['csv_importer_setting_import_model_checked'] = $this->request->post['csv_importer_setting_import_model_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_model_checked')) {
			 $data['csv_importer_setting_import_model_checked'] = $this->config->get('csv_importer_setting_import_model_checked');
		 } else {
			 $data['csv_importer_setting_import_model_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_price_checked'])) {
			 $data['csv_importer_setting_import_price_checked'] = $this->request->post['csv_importer_setting_import_price_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_price_checked')) {
			 $data['csv_importer_setting_import_price_checked'] = $this->config->get('csv_importer_setting_import_price_checked');
		 } else {
			 $data['csv_importer_setting_import_price_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_quantity_checked'])) {
			 $data['csv_importer_setting_import_quantity_checked'] = $this->request->post['csv_importer_setting_import_quantity_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_quantity_checked')) {
			 $data['csv_importer_setting_import_quantity_checked'] = $this->config->get('csv_importer_setting_import_quantity_checked');
		 } else {
			 $data['csv_importer_setting_import_quantity_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_statusenabled_checked'])) {
			 $data['csv_importer_setting_import_statusenabled_checked'] = $this->request->post['csv_importer_setting_import_statusenabled_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_statusenabled_checked')) {
			 $data['csv_importer_setting_import_statusenabled_checked'] = $this->config->get('csv_importer_setting_import_statusenabled_checked');
		 } else {
			 $data['csv_importer_setting_import_statusenabled_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_sku_checked'])) {
			 $data['csv_importer_setting_import_sku_checked'] = $this->request->post['csv_importer_setting_import_sku_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_sku_checked')) {
			 $data['csv_importer_setting_import_sku_checked'] = $this->config->get('csv_importer_setting_import_sku_checked');
		 } else {
			 $data['csv_importer_setting_import_sku_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_manufacturer_checked'])) {
			 $data['csv_importer_setting_import_manufacturer_checked'] = $this->request->post['csv_importer_setting_import_manufacturer_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_manufacturer_checked')) {
			 $data['csv_importer_setting_import_manufacturer_checked'] = $this->config->get('csv_importer_setting_import_manufacturer_checked');
		 } else {
			 $data['csv_importer_setting_import_manufacturer_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_description_checked'])) {
			 $data['csv_importer_setting_import_description_checked'] = $this->request->post['csv_importer_setting_import_description_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_description_checked')) {
			 $data['csv_importer_setting_import_description_checked'] = $this->config->get('csv_importer_setting_import_description_checked');
		 } else {
			 $data['csv_importer_setting_import_description_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_categories_checked'])) {
			 $data['csv_importer_setting_import_categories_checked'] = $this->request->post['csv_importer_setting_import_categories_checked'];
		 } elseif ($this->config->get('csv_importer_setting_import_categories_checked')) {
			 $data['csv_importer_setting_import_categories_checked'] = $this->config->get('csv_importer_setting_import_categories_checked');
		 } else {
			 $data['csv_importer_setting_import_categories_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_import_min_size'])) {
			 $data['csv_importer_setting_import_min_size'] = $this->request->post['csv_importer_setting_import_min_size'];
		 } elseif ($this->config->get('csv_importer_setting_import_min_size')) {
			 $data['csv_importer_setting_import_min_size'] = $this->config->get('csv_importer_setting_import_min_size');
		 } else {
			 $data['csv_importer_setting_import_min_size'] = 1;
		 }

		 if (isset($this->request->post['csv_importer_setting_import_max_size'])) {
			 $data['csv_importer_setting_import_max_size'] = $this->request->post['csv_importer_setting_import_max_size'];
		 } elseif ($this->config->get('csv_importer_setting_import_max_size')) {
			 $data['csv_importer_setting_import_max_size'] = $this->config->get('csv_importer_setting_import_max_size');
		 } else {
			 $data['csv_importer_setting_import_max_size'] = 500;
		 }

		 if (isset($this->request->post['csv_importer_setting_export_image'])) {
			 $data['csv_importer_setting_export_image'] = $this->request->post['csv_importer_setting_export_image'];
		 } elseif ($this->config->get('csv_importer_setting_export_image')) {
			 $data['csv_importer_setting_export_image'] = $this->config->get('csv_importer_setting_export_image');
		 } else {
			 $data['csv_importer_setting_export_image'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_name'])) {
			 $data['csv_importer_setting_export_name'] = $this->request->post['csv_importer_setting_export_name'];
		 } elseif ($this->config->get('csv_importer_setting_export_name')) {
			 $data['csv_importer_setting_export_name'] = $this->config->get('csv_importer_setting_export_name');
		 } else {
			 $data['csv_importer_setting_export_name'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_model'])) {
			 $data['csv_importer_setting_export_model'] = $this->request->post['csv_importer_setting_export_model'];
		 } elseif ($this->config->get('csv_importer_setting_export_model')) {
			 $data['csv_importer_setting_export_model'] = $this->config->get('csv_importer_setting_export_model');
		 } else {
			 $data['csv_importer_setting_export_model'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_price'])) {
			 $data['csv_importer_setting_export_price'] = $this->request->post['csv_importer_setting_export_price'];
		 } elseif ($this->config->get('csv_importer_setting_export_price')) {
			 $data['csv_importer_setting_export_price'] = $this->config->get('csv_importer_setting_export_price');
		 } else {
			 $data['csv_importer_setting_export_price'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_quantity'])) {
			 $data['csv_importer_setting_export_quantity'] = $this->request->post['csv_importer_setting_export_quantity'];
		 } elseif ($this->config->get('csv_importer_setting_export_quantity')) {
			 $data['csv_importer_setting_export_quantity'] = $this->config->get('csv_importer_setting_export_quantity');
		 } else {
			 $data['csv_importer_setting_export_quantity'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_statusenabled'])) {
			 $data['csv_importer_setting_export_statusenabled'] = $this->request->post['csv_importer_setting_export_statusenabled'];
		 } elseif ($this->config->get('csv_importer_setting_export_statusenabled')) {
			 $data['csv_importer_setting_export_statusenabled'] = $this->config->get('csv_importer_setting_export_statusenabled');
		 } else {
			 $data['csv_importer_setting_export_statusenabled'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_sku'])) {
			 $data['csv_importer_setting_export_sku'] = $this->request->post['csv_importer_setting_export_sku'];
		 } elseif ($this->config->get('csv_importer_setting_export_sku')) {
			 $data['csv_importer_setting_export_sku'] = $this->config->get('csv_importer_setting_export_sku');
		 } else {
			 $data['csv_importer_setting_export_sku'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_manufacturer'])) {
			 $data['csv_importer_setting_export_manufacturer'] = $this->request->post['csv_importer_setting_export_manufacturer'];
		 } elseif ($this->config->get('csv_importer_setting_export_manufacturer')) {
			 $data['csv_importer_setting_export_manufacturer'] = $this->config->get('csv_importer_setting_export_manufacturer');
		 } else {
			 $data['csv_importer_setting_export_manufacturer'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_description'])) {
			 $data['csv_importer_setting_export_description'] = $this->request->post['csv_importer_setting_export_description'];
		 } elseif ($this->config->get('csv_importer_setting_export_description')) {
			 $data['csv_importer_setting_export_description'] = $this->config->get('csv_importer_setting_export_description');
		 } else {
			 $data['csv_importer_setting_export_description'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_categories'])) {
			 $data['csv_importer_setting_export_categories'] = $this->request->post['csv_importer_setting_export_categories'];
		 } elseif ($this->config->get('csv_importer_setting_export_categories')) {
			 $data['csv_importer_setting_export_categories'] = $this->config->get('csv_importer_setting_export_categories');
		 } else {
			 $data['csv_importer_setting_export_categories'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_export_separator'])) {
			 $data['csv_importer_setting_export_separator'] = $this->request->post['csv_importer_setting_export_separator'];
		 } elseif ($this->config->get('csv_importer_setting_export_separator')) {
			 $data['csv_importer_setting_export_separator'] = $this->config->get('csv_importer_setting_export_separator');
		 } else {
			 $data['csv_importer_setting_export_separator'] = 0;
		 }

		 if (isset($this->request->post['csv_importer_setting_export_image_checked'])) {
			 $data['csv_importer_setting_export_image_checked'] = $this->request->post['csv_importer_setting_export_image_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_image_checked')) {
			 $data['csv_importer_setting_export_image_checked'] = $this->config->get('csv_importer_setting_export_image_checked');
		 } else {
			 $data['csv_importer_setting_export_image_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_name_checked'])) {
			 $data['csv_importer_setting_export_name_checked'] = $this->request->post['csv_importer_setting_export_name_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_name_checked')) {
			 $data['csv_importer_setting_export_name_checked'] = $this->config->get('csv_importer_setting_export_name_checked');
		 } else {
			 $data['csv_importer_setting_export_name_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_model_checked'])) {
			 $data['csv_importer_setting_export_model_checked'] = $this->request->post['csv_importer_setting_export_model_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_model_checked')) {
			 $data['csv_importer_setting_export_model_checked'] = $this->config->get('csv_importer_setting_export_model_checked');
		 } else {
			 $data['csv_importer_setting_export_model_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_price_checked'])) {
			 $data['csv_importer_setting_export_price_checked'] = $this->request->post['csv_importer_setting_export_price_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_price_checked')) {
			 $data['csv_importer_setting_export_price_checked'] = $this->config->get('csv_importer_setting_export_price_checked');
		 } else {
			 $data['csv_importer_setting_export_price_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_quantity_checked'])) {
			 $data['csv_importer_setting_export_quantity_checked'] = $this->request->post['csv_importer_setting_export_quantity_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_quantity_checked')) {
			 $data['csv_importer_setting_export_quantity_checked'] = $this->config->get('csv_importer_setting_export_quantity_checked');
		 } else {
			 $data['csv_importer_setting_export_quantity_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_statusenabled_checked'])) {
			 $data['csv_importer_setting_export_statusenabled_checked'] = $this->request->post['csv_importer_setting_export_statusenabled_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_statusenabled_checked')) {
			 $data['csv_importer_setting_export_statusenabled_checked'] = $this->config->get('csv_importer_setting_export_statusenabled_checked');
		 } else {
			 $data['csv_importer_setting_export_statusenabled_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_sku_checked'])) {
			 $data['csv_importer_setting_export_sku_checked'] = $this->request->post['csv_importer_setting_export_sku_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_sku_checked')) {
			 $data['csv_importer_setting_export_sku_checked'] = $this->config->get('csv_importer_setting_export_sku_checked');
		 } else {
			 $data['csv_importer_setting_export_sku_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_manufacturer_checked'])) {
			 $data['csv_importer_setting_export_manufacturer_checked'] = $this->request->post['csv_importer_setting_export_manufacturer_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_manufacturer_checked')) {
			 $data['csv_importer_setting_export_manufacturer_checked'] = $this->config->get('csv_importer_setting_export_manufacturer_checked');
		 } else {
			 $data['csv_importer_setting_export_manufacturer_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_description_checked'])) {
			 $data['csv_importer_setting_export_description_checked'] = $this->request->post['csv_importer_setting_export_description_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_description_checked')) {
			 $data['csv_importer_setting_export_description_checked'] = $this->config->get('csv_importer_setting_export_description_checked');
		 } else {
			 $data['csv_importer_setting_export_description_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_export_categories_checked'])) {
			 $data['csv_importer_setting_export_categories_checked'] = $this->request->post['csv_importer_setting_export_categories_checked'];
		 } elseif ($this->config->get('csv_importer_setting_export_categories_checked')) {
			 $data['csv_importer_setting_export_categories_checked'] = $this->config->get('csv_importer_setting_export_categories_checked');
		 } else {
			 $data['csv_importer_setting_export_categories_checked'] = '';
		 }

		 if (isset($this->request->post['csv_importer_setting_image_number'])) {
			 $data['csv_importer_setting_image_number'] = $this->request->post['csv_importer_setting_image_number'];
		 } elseif ($this->config->get('csv_importer_setting_image_number')) {
			 $data['csv_importer_setting_image_number'] = $this->config->get('csv_importer_setting_image_number');
		 } else {
			 $data['csv_importer_setting_image_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_name_number_number'])) {
			 $data['csv_importer_setting_name_number'] = $this->request->post['csv_importer_setting_name_number'];
		 } elseif ($this->config->get('csv_importer_setting_name_number')) {
			 $data['csv_importer_setting_name_number'] = $this->config->get('csv_importer_setting_name_number');
		 } else {
			 $data['csv_importer_setting_name_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_model_number'])) {
			 $data['csv_importer_setting_model_number'] = $this->request->post['csv_importer_setting_model_number'];
		 } elseif ($this->config->get('csv_importer_setting_model_number')) {
			 $data['csv_importer_setting_model_number'] = $this->config->get('csv_importer_setting_model_number');
		 } else {
			 $data['csv_importer_setting_model_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_price_number'])) {
			 $data['csv_importer_setting_price_number'] = $this->request->post['csv_importer_setting_price_number'];
		 } elseif ($this->config->get('csv_importer_setting_price_number')) {
			 $data['csv_importer_setting_price_number'] = $this->config->get('csv_importer_setting_price_number');
		 } else {
			 $data['csv_importer_setting_price_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_quantity_number'])) {
			 $data['csv_importer_setting_quantity_number'] = $this->request->post['csv_importer_setting_quantity_number'];
		 } elseif ($this->config->get('csv_importer_setting_quantity_number')) {
			 $data['csv_importer_setting_quantity_number'] = $this->config->get('csv_importer_setting_quantity_number');
		 } else {
			 $data['csv_importer_setting_quantity_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_statusenabled_number'])) {
			 $data['csv_importer_setting_statusenabled_number'] = $this->request->post['csv_importer_setting_statusenabled_number'];
		 } elseif ($this->config->get('csv_importer_setting_statusenabled_number')) {
			 $data['csv_importer_setting_statusenabled_number'] = $this->config->get('csv_importer_setting_statusenabled_number');
		 } else {
			 $data['csv_importer_setting_statusenabled_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_sku_number'])) {
			 $data['csv_importer_setting_sku_number'] = $this->request->post['csv_importer_setting_sku_number'];
		 } elseif ($this->config->get('csv_importer_setting_sku_number')) {
			 $data['csv_importer_setting_sku_number'] = $this->config->get('csv_importer_setting_sku_number');
		 } else {
			 $data['csv_importer_setting_sku_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_manufacturer_number'])) {
			 $data['csv_importer_setting_manufacturer_number'] = $this->request->post['csv_importer_setting_manufacturer_number'];
		 } elseif ($this->config->get('csv_importer_setting_manufacturer_number')) {
			 $data['csv_importer_setting_manufacturer_number'] = $this->config->get('csv_importer_setting_manufacturer_number');
		 } else {
			 $data['csv_importer_setting_manufacturer_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_description_number'])) {
			 $data['csv_importer_setting_description_number'] = $this->request->post['csv_importer_setting_description_number'];
		 } elseif ($this->config->get('csv_importer_setting_description_number')) {
			 $data['csv_importer_setting_description_number'] = $this->config->get('csv_importer_setting_description_number');
		 } else {
			 $data['csv_importer_setting_description_number'] = $this->language->get('not_data');
		 }

		 if (isset($this->request->post['csv_importer_setting_categories_number'])) {
			 $data['csv_importer_setting_categories_number'] = $this->request->post['csv_importer_setting_categories_number'];
		 } elseif ($this->config->get('csv_importer_setting_categories_number')) {
			 $data['csv_importer_setting_categories_number'] = $this->config->get('csv_importer_setting_categories_number');
		 } else {
			 $data['csv_importer_setting_categories_number'] = $this->language->get('not_data');
		 }
	 }
		
	public function settings(){

          if ($this->validate()) {
                 
             	 $value_temp = $this->request->post;
				 $value_temp = str_replace('&quot;', '"' , $value_temp);

			     $this->load->model('setting/setting');
			     $this->model_setting_setting->editSetting('csv_importer', $value_temp);

				 $this->output = array ( 'status' => 'Ok');
				 
				 $this->response->setOutput(json_encode($this->output));

		} else {

			// return error
			   return $this->forward('error/permission');
		}


    }	
	


	function return_bytes($val)
	{
		$val = trim($val);
	
		switch (strtolower(substr($val, -1)))
		{
			case 'm': $val = (int)substr($val, 0, -1) * 1048576; break;
			case 'k': $val = (int)substr($val, 0, -1) * 1024; break;
			case 'g': $val = (int)substr($val, 0, -1) * 1073741824; break;
			case 'b':
				switch (strtolower(substr($val, -2, 1)))
				{
					case 'm': $val = (int)substr($val, 0, -2) * 1048576; break;
					case 'k': $val = (int)substr($val, 0, -2) * 1024; break;
					case 'g': $val = (int)substr($val, 0, -2) * 1073741824; break;
					default : break;
				} break;
			default: break;
		}
		return $val;
	}
	
	
	//Upload from server
	public function load() {
	  
        $this->load->language('module/csv_importer');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('module/csv_importer');	  
		
		if ($this->validate()) {
           
			// send the categories, products and options as a spreadsheet file
		    if ($this->model_module_csv_importer->download() == true)
		    {
		       $this->session->data['success'] = $this->language->get('text_success');
			   
			}
			else 
			{
			   $this->error['warning'] = $this->language->get('error_upload');
			   $this->OutWiev();
			}
		} 
		else 
		{
		   
            // return error
            return $this->forward('error/permission');

		}
	
		
	}




	private function validate() {
		if (!$this->user->hasPermission('modify', 'module/csv_importer')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
}
?>